from __future__ import print_function

def main_func():
    print("stub")

if __name__ == "__main__":
    main_func()
